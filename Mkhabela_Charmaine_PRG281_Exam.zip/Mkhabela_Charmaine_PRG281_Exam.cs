﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _600439_Rodney_Mlotshwa_PRG_281_exam
{
    public interface IServiceCharge
    {
        void serviceCharge();
    }


    public class ServiceChargeEventArgs : EventArgs
    {
        public decimal Amount { get; set; }
        public decimal RemainingBalance { get; set; }
    }


    public abstract class Account : IServiceCharge
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public int AccountNumber { get; set; }
        public string AccountType { get; set; }
        public int ServiceChargeDate { get; set; }

        protected decimal balance;

        public decimal Balance
        {
            get { return balance; }
            protected set { balance = value; }
        }

        protected Account()
        {

        }


        protected Account(string name, string surname, int accountNumber, string accountType, int serviceChargeDate)
        {
            this.Name = name;
            this.Surname = surname;
            this.AccountNumber = accountNumber;
            this.AccountType = accountType;
            this.ServiceChargeDate = serviceChargeDate;
        }


        public virtual void Transfer(Account toAccount, decimal amount)
        {

            if (this.Name == toAccount.Name && this.Surname == toAccount.Surname)
            {

                if (this.balance >= amount)
                {
                    this.balance -= amount;
                    toAccount.balance += amount;
                    Console.WriteLine($"Transfer successful. New balance: {this.balance:C}");
                }
                else
                {
                    Console.WriteLine("Insufficient balance. Transfer failed.");
                }
            }
            else
            {
                Console.WriteLine("Accounts belong to different owners. Transfer not allowed.");
            }
        }


        public abstract void serviceCharge();


        public event EventHandler<ServiceChargeEventArgs> ServiceChargeDeducted;

        protected virtual void OnServiceChargeDeducted(decimal amount)
        {
            if (ServiceChargeDeducted != null)
            {
                ServiceChargeDeducted(this, new ServiceChargeEventArgs { Amount = amount, RemainingBalance = this.balance });
            }
        }
    }


    public class Savings : Account
    {

        public Savings() : base()
        {
            this.AccountType = "Savings";
            this.balance = 1000m;
        }

        public Savings(string name, string surname, int accountNumber, int serviceChargeDate, decimal balance)
            : base(name, surname, accountNumber, "Savings", serviceChargeDate)
        {
            this.balance = balance;
        }


        public override void serviceCharge()
        {
            decimal chargeAmount = 50m;
            this.balance -= chargeAmount;
            OnServiceChargeDeducted(chargeAmount);
        }
    }


    public class Current : Account
    {

        public Current() : base()
        {
            this.AccountType = "Current";
            this.balance = 500m;
        }

        public Current(string name, string surname, int accountNumber, int serviceChargeDate, decimal balance)
            : base(name, surname, accountNumber, "Current", serviceChargeDate)
        {
            this.balance = balance;
        }


        public override void serviceCharge()
        {
            decimal chargeAmount = 100m;
            this.balance -= chargeAmount;
            OnServiceChargeDeducted(chargeAmount);
        }
    }


    class Program
    {
        static void Main(string[] args)
        {

            List<Account> allAccounts = new List<Account>();


            Current susanCurrent = new Current("Susan", "Doe", 627856, 26, 1000m);

            Current jamesCurrent = new Current("James", "Doe", 627846, 26, 1000m);

            Savings susanSavings = new Savings("Susan", "Doe", 627756, 26, 500m);


            allAccounts.Add(susanCurrent);
            allAccounts.Add(jamesCurrent);
            allAccounts.Add(susanSavings);


            foreach (var account in allAccounts)
            {
                account.ServiceChargeDeducted += Account_ServiceChargeDeducted;
            }


            bool exit = false;
            while (!exit)
            {

                Console.WriteLine("\nPlease select an option:");
                Console.WriteLine("1. transfer");
                Console.WriteLine("2. service charges");
                Console.WriteLine("3. Exit app");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        PerformTransfer(allAccounts);
                        break;
                    case "2":
                        DeductServiceCharges(allAccounts);
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }

        private static void Account_ServiceChargeDeducted(object sender, ServiceChargeEventArgs e)
        {
            Account account = sender as Account;
            Console.WriteLine($"\nEmail to {account.Name} {account.Surname}: A service charge of {e.Amount:C} has been deducted from your account {account.AccountNumber}. Remaining balance: {e.RemainingBalance:C}");
        }

        private static void PerformTransfer(List<Account> allAccounts)
        {
            Console.WriteLine("\nEnter your account number:");
            if (!int.TryParse(Console.ReadLine(), out int fromAccountNumber))
            {
                Console.WriteLine("Invalid account number.");
                return;
            }

            Account fromAccount = allAccounts.Find(a => a.AccountNumber == fromAccountNumber);
            if (fromAccount == null)
            {
                Console.WriteLine("Account not found.");
                return;
            }

            Console.WriteLine("Enter the account number to transfer to:");
            if (!int.TryParse(Console.ReadLine(), out int toAccountNumber))
            {
                Console.WriteLine("Invalid account number.");
                return;
            }

            Account toAccount = allAccounts.Find(a => a.AccountNumber == toAccountNumber);
            if (toAccount == null)
            {
                Console.WriteLine("Account not found.");
                return;
            }


            if (fromAccount.Name != toAccount.Name || fromAccount.Surname != toAccount.Surname)
            {
                Console.WriteLine("Accounts belong to different owners. Transfer not allowed.");
                return;
            }

            Console.WriteLine("Enter amount to transfer:");
            if (!decimal.TryParse(Console.ReadLine(), out decimal amount))
            {
                Console.WriteLine("Invalid amount.");
                return;
            }


            fromAccount.Transfer(toAccount, amount);
        }

        private static void DeductServiceCharges(List<Account> allAccounts)
        {

            int currentDate = DateTime.Now.Day;

            foreach (var account in allAccounts)
            {
                if (account.ServiceChargeDate == currentDate)
                {
                    account.serviceCharge();
                }
            }
        }
    }
}
